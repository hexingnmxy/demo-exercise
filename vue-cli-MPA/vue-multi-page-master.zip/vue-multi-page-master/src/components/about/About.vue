<template>
	<h1>This is about module!</h1>
</template>

<script></script>

<style scoped>
	h1{
		color: rgb(5, 110, 234);
	}
</style>