<template>
	<h1>This is Foot!</h1>
</template>

<script></script>

<style scoped>
	h1{
		color: green;
	}
</style>