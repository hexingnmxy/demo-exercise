<template>
	<h1>This is Head!</h1>
</template>

<script></script>

<!-- 加入scoped是为了防止本组件中的css渗透到其他组件，可以去掉看看结果 -->
<style scoped>
	h1{
		color: black;
	}
</style>