<template>
  <div class="title-group-wrap">
    <p class="title-group-title">{{titleText}}</p>
    <p class="title-group-tips">{{tipsText}}</p>
  </div>
</template>
<script>
  import './style';
  import main from './main';
  export default main;
</script>
