export default {
	props: {
		topHeight: {
			type: String,
			default() {
				return '0';
			}
		},
		topBottom: {
			type: String,
			default() {
				return '0';
			}
		}
	}
};
