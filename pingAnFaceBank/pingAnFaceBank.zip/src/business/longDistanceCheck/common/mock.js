export default [
	{
		url: '/mmarket/RemoteCheck.CheckUmId.do',
		response: {
			data: {
				'ReturnCode': '000000',
				'ReturnMessage': '交易成功',
				'ReturnFlag': '0',
				'BusinessJnlNo': 'ldoNSGtWDKzenFCYJOhPv1VwnkA5GiM4YE1zXVO9xCk='
			}
		}
	}
];
