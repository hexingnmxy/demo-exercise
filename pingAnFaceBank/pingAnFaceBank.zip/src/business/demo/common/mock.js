export default [
	{
		url: 'http://api.map.baidu.com/geoconv/v1/?',
		response: {
			body: {
				name: 'HanMei',
				gender: 'F'
			}
		}
	},
	{
		url: 'bbbb',
		response: {
			body: {
				name: 'YaoMing',
				gender: 'M'
			}
		}
	}
];
