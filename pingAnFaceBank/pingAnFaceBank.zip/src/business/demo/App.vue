<template>
    <div>
      Hi:
      <router-view></router-view>
    </div>
</template>
<script>
    import '../../styles/_init.less';
    export default {
        components:{
        }
    }
</script>
