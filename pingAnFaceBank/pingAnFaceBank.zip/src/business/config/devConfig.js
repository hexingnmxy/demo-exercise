window.env = 'dev'; // 当前是开发环境

