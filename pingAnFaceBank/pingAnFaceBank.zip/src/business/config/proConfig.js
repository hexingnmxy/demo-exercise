// window.env = 'pro'; // 当前是生产环境
window.env = 'dev'; // 当前是生产环境

