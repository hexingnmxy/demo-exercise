const Server = {
	longDistanceCheck: { // 远程检查
		proId: 'RemoteCheck', // 业务ID
		CheckUmId: '/mmarket/RemoteCheck.CheckUmId.do'
	}
};

const PRODUCT = {};

const EBANK = {};

const CameraTypeCode = {};

export {
	Server, PRODUCT, EBANK, CameraTypeCode
};
