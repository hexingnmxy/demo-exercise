export default {
	data() {
		return {

		};
	},
	props: {
		title: {
			type: String,
			default() {
				return '';
			}
		}
	},
	methods: {

	},
	components: {

	}
};
