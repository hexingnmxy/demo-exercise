// import PaSort from 'pingan-ui/dist/components/sort';
// import PaSort from '../../../../../src-ui/components/sort';
import PaSort from 'pingan-ui/components/sort';
import PaContentSample from '../../components/content-sample';
import PaContentSampleHeader from '../../components/content-sample-header';

export default {
	components: {
		PaSort,
		PaContentSample,
		PaContentSampleHeader
	}
};
