export default {
	components: {

	},
	methods: {

	},
	data() {
		return {
			colorListOne: [
				{
					title: '#fa8919',
					text: '标准橘色 项目风格颜色'
				},
				{
					title: '#ffa033',
					text: '亮橘色'
				},
				{
					title: '#cccccc',
					text: '80%灰色'
				},
				{
					title: '#adadad',
					text: '68%灰色'
				},
				{
					title: '#999999',
					text: '60%灰色'
				},
				{
					title: '#666666',
					text: '40%灰色'
				},
				{
					title: '#333333',
					text: '20%灰色'
				}
			],
			colorListTwo: [
				{
					title: '#ffffff',
					text: '白色'
				},
				{
					title: '#fafafa',
					text: '98%灰色'
				},
				{
					title: '#f0f0f0',
					text: '94%灰色'
				},
				{
					title: '#ebebeb',
					text: '92%灰色'
				},
				{
					title: '#e5e5e5',
					text: '90%灰色'
				}
			]
		};
	}
};
