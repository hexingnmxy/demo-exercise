import ContentSampleHeader from '../../components/content-sample-header/index';

export default {
	data() {
		return {
			// fontList:[
			//   {
			//     size: '0.12rem',
			//     weight:'',
			//     text: '演示文字'
			//   },
			//   {
			//     size: '0.12rem',
			//     weight:'bold',
			//     text: '演示文字加粗'
			//   },
			//   {
			//     size: '0.14rem',
			//     weight:'',
			//     text: '演示文字'
			//   },
			//   {
			//     size: '0.14rem',
			//     weight:'bold',
			//     text: '演示文字加粗'
			//   },
			//   {
			//     size: '0.16rem',
			//     weight:'',
			//     text: '演示文字'
			//   },
			//   {
			//     size: '0.16rem',
			//     weight:'bold',
			//     text: '演示文字加粗'
			//   },
			//   {
			//     size: '0.18rem',
			//     weight:'',
			//     text: '演示文字'
			//   },
			//   {
			//     size: '0.18rem',
			//     weight:'bold',
			//     text: '演示文字加粗'
			//   },
			//   {
			//     size: '0.20rem',
			//     weight:'',
			//     text: '演示文字'
			//   },
			//   {
			//     size: '0.20rem',
			//     weight:'bold',
			//     text: '演示文字加粗'
			//   },
			//   {
			//     size: '0.22rem',
			//     weight:'',
			//     text: '演示文字'
			//   },
			//   {
			//     size: '0.22rem',
			//     weight:'bold',
			//     text: '演示文字加粗'
			//   },
			//   {
			//     size: '0.24rem',
			//     weight:'',
			//     text: '演示文字'
			//   },
			//   {
			//     size: '0.24rem',
			//     weight:'bold',
			//     text: '演示文字加粗'
			//   },
			//   {
			//     size: '0.26rem',
			//     weight:'',
			//     text: '演示文字'
			//   },
			//   {
			//     size: '0.26rem',
			//     weight:'bold',
			//     text: '演示文字加粗'
			//   },
			//   {
			//     size: '0.28rem',
			//     weight:'',
			//     text: '演示文字'
			//   },
			//   {
			//     size: '0.28rem',
			//     weight:'bold',
			//     text: '演示文字加粗'
			//   },
			//   {
			//     size: '0.30rem',
			//     weight:'',
			//     text: '演示文字'
			//   },
			//   {
			//     size: '0.30rem',
			//     weight:'bold',
			//     text: '演示文字加粗'
			//   },
			//   {
			//     size: '0.32rem',
			//     weight:'',
			//     text: '演示文字'
			//   },
			//   {
			//     size: '0.32rem',
			//     weight:'bold',
			//     text: '演示文字加粗'
			//   },
			//   {
			//     size: '0.34rem',
			//     weight:'',
			//     text: '演示文字'
			//   },
			//   {
			//     size: '0.34rem',
			//     weight:'bold',
			//     text: '演示文字加粗'
			//   }
			// ]
		};
	},
	components: {
		ContentSampleHeader
	}
};
