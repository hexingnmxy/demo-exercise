// import PaButton from 'pingan-ui/dist/components/button';
// import PaButton from '../../../../../src-ui/components/button/index';
import PaButton from 'pingan-ui/components/button/index';
import PaContentSample from '../../components/content-sample';
import PaContentSampleHeader from '../../components/content-sample-header';

export default {
	components: {
		PaButton,
		PaContentSample,
		PaContentSampleHeader
	}
};
