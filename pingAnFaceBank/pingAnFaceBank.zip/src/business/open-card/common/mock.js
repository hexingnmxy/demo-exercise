export default [
	{
		url: 'http://api.map.baidu.com/geoconv/v1/?',
		response: {
			data: {
				name: 'HanMei',
				gender: 'F'
			}
		}
	},
	{
		url: 'bbbb',
		response: {
			data: {
				name: 'YaoMing',
				gender: 'M'
			}
		}
	}
];
