export default {
	data() {
		return {
		};
	},
	mounted() {
		this.$nextTick(() => {

		});
	},
	props: {
		value: {}
	},
	methods: {

	},
	computed: {
		disabled() {
			return this.value;
		}
	},
	components: {

	}
};
