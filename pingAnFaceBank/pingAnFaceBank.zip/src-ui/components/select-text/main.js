export default {
	data() {
		return {};
	},
	props: {},
	components: {},
	computed: {},
	methods: {}
};
