<template>
  <span class="select-item-text">
    <slot></slot>
  </span>
</template>
<script>
  import './style';
  import main from './main';
  export default main;
</script>
