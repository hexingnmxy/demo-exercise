<template>
    <span :class="type"></span>
</template>
<script>
    import '../../styles/ui/_icon';
    import main from './main';
    export default main;
</script>
