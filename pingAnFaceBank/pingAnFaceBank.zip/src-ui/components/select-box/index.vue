<template>
    <div class="pop-box-title-content">
        <slot></slot>
    </div>
</template>
<script>
  import './style';
  import main from './main';
  export default main;
</script>
