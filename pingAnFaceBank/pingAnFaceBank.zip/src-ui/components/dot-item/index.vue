<template>
  <div class="dot-item">
    <slot></slot>
  </div>
</template>
<script>
  import main from './main';
  import './style';
  export default main;
</script>
