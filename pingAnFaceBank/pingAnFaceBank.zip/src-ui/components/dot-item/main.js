export default {
	data() {
		return {
		};
	},
	props: {
	},
	computed: {
	}
};
