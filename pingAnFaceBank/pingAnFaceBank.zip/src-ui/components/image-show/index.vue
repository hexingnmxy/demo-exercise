<template>

  <div :class="background"
       :style="{'backgroundImage': backgroundImage}">
  </div>

</template>
<script>
  import main from './main';
  import './style';
  export default main;
</script>
